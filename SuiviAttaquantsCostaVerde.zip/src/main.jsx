
import React from 'react'
import ReactDOM from 'react-dom/client'
import SuiviAttaquants from './SuiviAttaquants'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <SuiviAttaquants />
  </React.StrictMode>
)
